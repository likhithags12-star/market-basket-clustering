/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#231D2E',
        slate: { 925: '#1A1524' },
        plum: '#7A4F8C',
        saffron: '#D98A3D',
        pine: '#3E8265',
        paper: '#F7F6F8',
      },
      fontFamily: {
        sans: ['"Mulish"', 'system-ui', 'sans-serif'],
        display: ['"Fraunces"', 'serif'],
      },
    },
  },
  plugins: [],
}
