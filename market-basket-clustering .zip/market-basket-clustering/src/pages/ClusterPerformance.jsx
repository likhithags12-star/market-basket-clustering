import React from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import { colorForCluster } from '../utils/colors'

export default function ClusterPerformance({ customers, segments, k, clustering }) {
  const sizeData = segments.map((s) => ({ name: s.name, count: s.count, segment: s.segment }))

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Number of Clusters" value={k} />
        <StatCard label="Number of Customers" value={customers.length} />
        <StatCard label="Inertia" value={clustering.inertia.toFixed(2)} sublabel="Lower is tighter clusters" />
        <StatCard label="Silhouette Score" value={clustering.silhouette.toFixed(3)} sublabel="Closer to 1 is better separation" />
      </div>

      <ChartCard title="Cluster Size" description="Number of customers assigned to each segment">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={sizeData} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
            <CartesianGrid stroke="#eae7ee" vertical={false} />
            <XAxis dataKey="name" tick={{ fontSize: 9 }} interval={0} angle={-15} textAnchor="end" height={50} />
            <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
            <Tooltip />
            <Bar dataKey="count" radius={[4, 4, 0, 0]}>
              {sizeData.map((d, i) => <Cell key={i} fill={colorForCluster(d.segment)} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  )
}
