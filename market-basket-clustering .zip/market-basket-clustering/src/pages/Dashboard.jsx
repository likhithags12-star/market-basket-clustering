import React, { useMemo } from 'react'
import {
  ScatterChart, Scatter, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
} from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import { computeTransactionSummary, categoryPopularity } from '../services/dataset'
import { formatINR } from '../utils/currency'
import { colorForCluster } from '../utils/colors'

export default function Dashboard({ transactions, customers, segments, k }) {
  const summary = computeTransactionSummary(transactions, customers)
  const categoryPop = useMemo(() => categoryPopularity(transactions), [transactions])

  const distribution = segments.map((s) => ({ name: s.name, count: s.count, segment: s.segment }))
  const spendingBySegment = segments.map((s) => ({ name: s.name, spending: Math.round(s.avgSpending), segment: s.segment }))

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        <StatCard label="Total Transactions" value={summary.totalTransactions} />
        <StatCard label="Total Customers" value={summary.totalCustomers} />
        <StatCard label="Total Products" value={summary.totalProducts} />
        <StatCard label="Average Basket Value" value={formatINR(summary.averageBasketValue)} />
        <StatCard label="Average Purchase Frequency" value={summary.averagePurchaseFrequency.toFixed(1)} />
        <StatCard label="Total Revenue" value={formatINR(summary.totalRevenue)} />
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <ChartCard title="Spending vs Purchase Frequency" description="Each point is one customer, colored by segment" className="md:col-span-2">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#eae7ee" />
              <XAxis type="number" dataKey="total_spending" name="Spending" tick={{ fontSize: 11 }} />
              <YAxis type="number" dataKey="purchase_frequency" name="Frequency" tick={{ fontSize: 11 }} />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} formatter={(v, name) => (name === 'Spending' ? formatINR(v) : v)} />
              <Scatter data={customers}>
                {customers.map((c, i) => (
                  <Cell key={i} fill={colorForCluster(c.segment)} />
                ))}
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Customer Segment Distribution" description="Number of customers per segment">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={distribution} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#eae7ee" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 9 }} interval={0} angle={-15} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                {distribution.map((d, i) => <Cell key={i} fill={colorForCluster(d.segment)} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Average Spending by Segment">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={spendingBySegment} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#eae7ee" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 9 }} interval={0} angle={-15} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip formatter={(v) => formatINR(v)} />
              <Bar dataKey="spending" radius={[4, 4, 0, 0]}>
                {spendingBySegment.map((d, i) => <Cell key={i} fill={colorForCluster(d.segment)} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Product Category Popularity" description="Units sold by category" className="md:col-span-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={categoryPop} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#eae7ee" vertical={false} />
              <XAxis dataKey="category" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="unitsSold" fill="#7A4F8C" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  )
}
