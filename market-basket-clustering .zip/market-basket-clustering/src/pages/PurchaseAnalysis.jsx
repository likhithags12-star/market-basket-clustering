import React, { useMemo, useState } from 'react'
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import CustomerTable from '../components/CustomerTable'
import CustomerDetails from '../components/CustomerDetails'
import { computeTransactionSummary, productPopularity, categoryPopularity, histogram } from '../services/dataset'
import { computeMeanStd } from '../ml/preprocessing'
import { formatINR } from '../utils/currency'

function transactionTrend(transactions) {
  const byDate = {}
  transactions.forEach((t) => {
    const day = t.transaction_date.slice(0, 7) // group by month
    byDate[day] = (byDate[day] || 0) + t.total_amount
  })
  return Object.entries(byDate)
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([month, revenue]) => ({ month, revenue: Math.round(revenue) }))
}

export default function PurchaseAnalysis({ transactions, customers, segments }) {
  const [selected, setSelected] = useState(null)
  const summary = computeTransactionSummary(transactions, customers)
  const overallStats = useMemo(() => computeMeanStd(customers), [customers])

  const products = useMemo(() => productPopularity(transactions).slice(0, 8), [transactions])
  const categories = useMemo(() => categoryPopularity(transactions), [transactions])
  const trend = useMemo(() => transactionTrend(transactions), [transactions])
  const spendingDist = useMemo(() => histogram(customers.map((c) => c.total_spending)), [customers])

  const avgTxnValue = transactions.reduce((a, t) => a + t.total_amount, 0) / new Set(transactions.map((t) => t.transaction_id)).size
  const avgQtyPerTxn = transactions.reduce((a, t) => a + t.quantity, 0) / new Set(transactions.map((t) => t.transaction_id)).size
  const mostPurchasedCategory = [...categories].sort((a, b) => b.unitsSold - a.unitsSold)[0]?.category || '—'
  const mostPurchasedProduct = [...products].sort((a, b) => b.unitsSold - a.unitsSold)[0]?.product_name || '—'
  const highestRevenueCategory = [...categories].sort((a, b) => b.revenue - a.revenue)[0]?.category || '—'

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        <StatCard label="Total Transactions" value={summary.totalTransactions} />
        <StatCard label="Average Transaction Value" value={formatINR(avgTxnValue)} />
        <StatCard label="Average Quantity per Transaction" value={avgQtyPerTxn.toFixed(1)} />
        <StatCard label="Most Purchased Category" value={mostPurchasedCategory} />
        <StatCard label="Most Purchased Product" value={mostPurchasedProduct} />
        <StatCard label="Highest Revenue Category" value={highestRevenueCategory} />
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <ChartCard title="Category Sales" description="Units sold by category">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={categories} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#eae7ee" vertical={false} />
              <XAxis dataKey="category" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="unitsSold" fill="#7A4F8C" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Product Popularity" description="Top products by units sold">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={products} layout="vertical" margin={{ top: 10, right: 20, bottom: 0, left: 10 }}>
              <CartesianGrid stroke="#eae7ee" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11 }} />
              <YAxis type="category" dataKey="product_name" tick={{ fontSize: 10 }} width={110} />
              <Tooltip />
              <Bar dataKey="unitsSold" fill="#D98A3D" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Transaction Trends" description="Monthly revenue over time">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={trend} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#eae7ee" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip formatter={(v) => formatINR(v)} />
              <Line type="monotone" dataKey="revenue" stroke="#3E8265" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Spending Distribution" description="Customers by total spending">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={spendingDist} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#eae7ee" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 9 }} interval={0} angle={-20} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#7A4F8C" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2">
          <CustomerTable
            customers={customers}
            segmentNames={segments}
            onSelect={setSelected}
            selectedId={selected?.customer_id}
          />
        </div>
        <CustomerDetails customer={selected} segmentNames={segments} overallStats={overallStats} />
      </div>
    </div>
  )
}
