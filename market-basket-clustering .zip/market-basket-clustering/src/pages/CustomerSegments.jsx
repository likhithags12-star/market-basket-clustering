import React, { useMemo, useRef, useState } from 'react'
import SegmentCard from '../components/SegmentCard'
import ClusterVisualization from '../components/ClusterVisualization'
import ReportButton from '../components/ReportButton'
import { computeTransactionSummary, productPopularity, categoryPopularity } from '../services/dataset'

const K_OPTIONS = [2, 3, 4, 5, 6]

export default function CustomerSegments({ transactions, customers, segments, k, onKChange, clustering }) {
  const [selectedSegment, setSelectedSegment] = useState(null)
  const chartRef = useRef(null)
  const summary = computeTransactionSummary(transactions, customers)

  const purchaseInsights = useMemo(() => {
    const products = productPopularity(transactions)
    const categories = categoryPopularity(transactions)
    const byUnits = [...products].sort((a, b) => b.unitsSold - a.unitsSold)
    const byRevenue = [...categories].sort((a, b) => b.revenue - a.revenue)
    return {
      mostPurchasedProduct: byUnits[0]?.product_name || '—',
      mostPurchasedCategory: [...categories].sort((a, b) => b.unitsSold - a.unitsSold)[0]?.category || '—',
      highestRevenueCategory: byRevenue[0]?.category || '—',
    }
  }, [transactions])

  const highlighted = selectedSegment === null
    ? customers
    : customers.filter((c) => c.segment === selectedSegment)

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border border-black/5 p-4 flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
        <div>
          <p className="text-sm text-ink/70 font-medium mb-1">Number of Clusters</p>
          <div className="flex gap-2">
            {K_OPTIONS.map((opt) => (
              <button
                key={opt}
                onClick={() => onKChange(opt)}
                className={`w-9 h-9 rounded-md text-sm font-medium transition-colors ${
                  k === opt ? 'bg-ink text-white' : 'bg-black/5 text-ink/60 hover:bg-black/10'
                }`}
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
        <ReportButton
          summary={summary}
          k={k}
          segments={segments}
          clustering={clustering}
          purchaseInsights={purchaseInsights}
          chartElement={chartRef.current}
        />
      </div>

      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {segments.map((s) => (
          <SegmentCard
            key={s.segment}
            segment={s}
            selected={selectedSegment === s.segment}
            onSelect={() => setSelectedSegment(selectedSegment === s.segment ? null : s.segment)}
          />
        ))}
      </div>

      <ClusterVisualization
        innerRef={chartRef}
        customers={highlighted}
        description={selectedSegment === null ? 'Total spending vs purchase frequency, colored by segment' : `Highlighting ${segments[selectedSegment]?.name}`}
      />
    </div>
  )
}
