export const FEATURE_COLUMNS = [
  'purchase_frequency',
  'total_spending',
  'average_basket_value',
  'total_quantity',
  'unique_products',
  'unique_categories',
  'recency',
]

/** Computes per-feature min/max across the customer feature rows. */
export function computeStats(customers) {
  const stats = {}
  FEATURE_COLUMNS.forEach((col) => {
    const values = customers.map((c) => c[col])
    stats[col] = { min: Math.min(...values), max: Math.max(...values) }
  })
  return stats
}

export function normalizeValue(value, min, max) {
  if (max === min) return 0
  return (value - min) / (max - min)
}

/**
 * Builds the normalized feature matrix used for clustering: the numeric
 * behavioral features, plus one already-0..1 category-preference feature
 * per category found in the dataset.
 */
export function buildFeatureMatrix(customers, stats, categories) {
  return customers.map((c) => {
    const numeric = FEATURE_COLUMNS.map((col) => normalizeValue(c[col], stats[col].min, stats[col].max))
    const preferences = categories.map((cat) => c.categoryPreferences[cat] || 0)
    return [...numeric, ...preferences]
  })
}

export function computeMeanStd(customers) {
  const result = {}
  FEATURE_COLUMNS.forEach((col) => {
    const values = customers.map((c) => c[col])
    const mean = values.reduce((a, b) => a + b, 0) / values.length
    const variance = values.reduce((a, v) => a + (v - mean) ** 2, 0) / values.length
    result[col] = { mean, std: Math.sqrt(variance) || 1 }
  })
  return result
}
