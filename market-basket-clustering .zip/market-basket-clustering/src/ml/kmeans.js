// Lightweight, dependency-free K-Means implementation (k-means++ init + Lloyd's algorithm).
// Operates on a normalized numeric feature matrix (array of arrays).

function seededRandom(seed) {
  let s = seed
  return () => {
    s = (s * 9301 + 49297) % 233280
    return s / 233280
  }
}

function squaredDistance(a, b) {
  let sum = 0
  for (let i = 0; i < a.length; i++) {
    const d = a[i] - b[i]
    sum += d * d
  }
  return sum
}

function kMeansPlusPlusInit(matrix, k, random) {
  const n = matrix.length
  const centroids = []
  const firstIdx = Math.floor(random() * n)
  centroids.push([...matrix[firstIdx]])

  while (centroids.length < k) {
    const distances = matrix.map((point) => {
      let minDist = Infinity
      centroids.forEach((c) => {
        const d = squaredDistance(point, c)
        if (d < minDist) minDist = d
      })
      return minDist
    })
    const total = distances.reduce((a, b) => a + b, 0)
    if (total === 0) {
      // All remaining points coincide with existing centroids — pick any point.
      centroids.push([...matrix[Math.floor(random() * n)]])
      continue
    }
    let threshold = random() * total
    let chosenIdx = 0
    for (let i = 0; i < distances.length; i++) {
      threshold -= distances[i]
      if (threshold <= 0) {
        chosenIdx = i
        break
      }
    }
    centroids.push([...matrix[chosenIdx]])
  }
  return centroids
}

/**
 * Runs K-Means on a normalized feature matrix.
 * Returns { assignments: number[], centroids: number[][], iterations: number }.
 */
export function runKMeans(matrix, k, { maxIterations = 100, seed = 42 } = {}) {
  if (!matrix.length) throw new Error('No data available for clustering.')
  if (k < 1 || k > matrix.length) throw new Error('Invalid number of clusters requested.')

  const random = seededRandom(seed)
  let centroids = kMeansPlusPlusInit(matrix, k, random)
  let assignments = new Array(matrix.length).fill(-1)
  let iterations = 0

  for (let iter = 0; iter < maxIterations; iter++) {
    iterations = iter + 1
    let changed = false
    const newAssignments = matrix.map((point) => {
      let best = 0
      let bestDist = Infinity
      centroids.forEach((c, ci) => {
        const d = squaredDistance(point, c)
        if (d < bestDist) {
          bestDist = d
          best = ci
        }
      })
      return best
    })

    for (let i = 0; i < newAssignments.length; i++) {
      if (newAssignments[i] !== assignments[i]) {
        changed = true
        break
      }
    }
    assignments = newAssignments

    // Recompute centroids as the mean of assigned points.
    const sums = Array.from({ length: k }, () => new Array(matrix[0].length).fill(0))
    const counts = new Array(k).fill(0)
    matrix.forEach((point, i) => {
      const c = assignments[i]
      counts[c] += 1
      point.forEach((v, d) => { sums[c][d] += v })
    })

    const newCentroids = sums.map((sum, ci) => {
      if (counts[ci] === 0) {
        // Empty cluster: reseed at the point farthest from its current centroid.
        let farthestIdx = 0
        let farthestDist = -1
        matrix.forEach((point, i) => {
          const d = squaredDistance(point, centroids[assignments[i]])
          if (d > farthestDist) {
            farthestDist = d
            farthestIdx = i
          }
        })
        return [...matrix[farthestIdx]]
      }
      return sum.map((s) => s / counts[ci])
    })

    centroids = newCentroids
    if (!changed) break
  }

  return { assignments, centroids, iterations }
}

export function computeInertia(matrix, assignments, centroids) {
  let total = 0
  matrix.forEach((point, i) => {
    total += squaredDistance(point, centroids[assignments[i]])
  })
  return total
}

/**
 * Standard silhouette score. O(n^2) — fine for a few hundred points in-browser.
 */
export function computeSilhouetteScore(matrix, assignments, k) {
  const n = matrix.length
  if (k < 2 || n < 3) return 0

  const distance = (a, b) => Math.sqrt(squaredDistance(a, b))

  const clusterIndices = Array.from({ length: k }, () => [])
  assignments.forEach((c, i) => clusterIndices[c].push(i))

  let totalScore = 0
  let counted = 0

  for (let i = 0; i < n; i++) {
    const ci = assignments[i]
    const sameCluster = clusterIndices[ci].filter((idx) => idx !== i)

    if (sameCluster.length === 0) continue // singleton cluster: skip, undefined a(i)

    const a = sameCluster.reduce((sum, j) => sum + distance(matrix[i], matrix[j]), 0) / sameCluster.length

    let b = Infinity
    for (let c = 0; c < k; c++) {
      if (c === ci || clusterIndices[c].length === 0) continue
      const meanDist = clusterIndices[c].reduce((sum, j) => sum + distance(matrix[i], matrix[j]), 0) / clusterIndices[c].length
      if (meanDist < b) b = meanDist
    }
    if (b === Infinity) continue

    const s = (b - a) / Math.max(a, b)
    totalScore += s
    counted += 1
  }

  return counted > 0 ? totalScore / counted : 0
}
