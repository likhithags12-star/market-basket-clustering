import { computeStats, buildFeatureMatrix } from './preprocessing'
import { runKMeans, computeInertia, computeSilhouetteScore } from './kmeans'
import { buildCustomerFeatures, uniqueCategories } from '../utils/customerFeatures'

/**
 * Runs the full pipeline: aggregate transactions into customer features,
 * then cluster those features for a given K.
 */
export function segmentCustomers(transactions, k) {
  const categories = uniqueCategories(transactions)
  const customerFeatures = buildCustomerFeatures(transactions)

  const stats = computeStats(customerFeatures)
  const matrix = buildFeatureMatrix(customerFeatures, stats, categories)

  const { assignments, centroids, iterations } = runKMeans(matrix, k, { seed: 42 })
  const inertia = computeInertia(matrix, assignments, centroids)
  const silhouette = computeSilhouetteScore(matrix, assignments, k)

  const customers = customerFeatures.map((c, i) => ({ ...c, segment: assignments[i] }))

  const clusterSizes = new Array(k).fill(0)
  assignments.forEach((c) => { clusterSizes[c] += 1 })

  return {
    k,
    categories,
    stats,
    customers,
    assignments,
    centroids,
    iterations,
    inertia,
    silhouette,
    clusterSizes,
  }
}
