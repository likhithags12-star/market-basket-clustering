import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'
import { formatINR } from './currency'

const APP_NAME = 'Market Basket Analysis'
const REPORT_TITLE = 'Customer Segmentation Report'

/**
 * Builds and downloads a PDF customer-segmentation report.
 * chartElement is an optional DOM node captured as an image and embedded
 * in the PDF. If capture fails, the report still generates without it.
 */
export async function generateSegmentationReportPdf({ summary, k, segments, clustering, purchaseInsights, chartElement }) {
  if (!segments || segments.length === 0) {
    throw new Error('Please wait for segmentation to complete first.')
  }
  if (!clustering) {
    throw new Error('Clustering metrics are not available yet. Please wait for segmentation to finish.')
  }

  const doc = new jsPDF({ unit: 'pt', format: 'a4' })
  const pageWidth = doc.internal.pageSize.getWidth()
  const pageHeight = doc.internal.pageSize.getHeight()
  const margin = 48
  let y = margin

  const ensureSpace = (needed) => {
    if (y + needed > pageHeight - margin) {
      doc.addPage()
      y = margin
    }
  }

  const line = (text, size = 11, weight = 'normal', gap = 16) => {
    ensureSpace(gap)
    doc.setFont('helvetica', weight)
    doc.setFontSize(size)
    doc.text(text, margin, y)
    y += gap
  }

  // Header
  doc.setFillColor(35, 29, 46)
  doc.rect(0, 0, pageWidth, 78, 'F')
  doc.setTextColor(255, 255, 255)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(16)
  doc.text(APP_NAME, margin, 30)
  doc.setFontSize(12)
  doc.text(REPORT_TITLE, margin, 48)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9)
  doc.text(`Report generated: ${new Date().toLocaleString()}  |  Clusters (K): ${k}`, margin, 64)
  doc.setTextColor(35, 29, 46)
  y = 108

  // Dataset summary
  line('Dataset Summary', 13, 'bold', 20)
  line(`Total Transactions: ${summary.totalTransactions}`)
  line(`Total Customers: ${summary.totalCustomers}`)
  line(`Total Products: ${summary.totalProducts}`)
  line(`Total Revenue: ${formatINR(summary.totalRevenue)}`)
  line(`Average Basket Value: ${formatINR(summary.averageBasketValue)}`)
  y += 8

  // Clustering metrics
  line('Clustering Metrics', 13, 'bold', 20)
  line(`Number of Clusters: ${k}`)
  line(`Inertia: ${clustering.inertia.toFixed(3)}`)
  line(`Silhouette Score: ${clustering.silhouette.toFixed(3)}`)
  y += 8

  // Purchase insights
  if (purchaseInsights) {
    line('Purchase Insights', 13, 'bold', 20)
    line(`Most Purchased Category: ${purchaseInsights.mostPurchasedCategory}`)
    line(`Most Purchased Product: ${purchaseInsights.mostPurchasedProduct}`)
    line(`Highest Revenue Category: ${purchaseInsights.highestRevenueCategory}`)
    y += 8
  }

  // Segment summaries
  line('Segment Summary', 13, 'bold', 20)
  segments.forEach((s) => {
    ensureSpace(120)
    line(`${s.name} (Segment ${s.segment + 1})`, 12, 'bold', 16)
    line(`Customer Count: ${s.count}`)
    line(`Average Spending: ${formatINR(s.avgSpending)}`)
    line(`Purchase Frequency: ${s.avgFrequency.toFixed(1)}`)
    line(`Average Basket Value: ${formatINR(s.avgBasketValue)}`)
    line(`Average Quantity: ${s.avgQuantity.toFixed(1)}`)
    line(`Unique Products: ${s.avgUniqueProducts.toFixed(1)}`)
    line(`Average Recency: ${Math.round(s.avgRecency)} days`)
    line(`Top Categories: ${s.topCategories.join(', ') || '—'}`)
    const wrapped = doc.splitTextToSize(s.summary, pageWidth - margin * 2)
    ensureSpace(wrapped.length * 14 + 10)
    doc.setFont('helvetica', 'italic')
    doc.setFontSize(10)
    doc.text(wrapped, margin, y)
    y += wrapped.length * 14 + 14
  })

  // Chart (best effort)
  if (chartElement) {
    try {
      const canvas = await html2canvas(chartElement, { backgroundColor: '#ffffff', scale: 2 })
      const imgData = canvas.toDataURL('image/png')
      const imgWidth = pageWidth - margin * 2
      const imgHeight = (canvas.height / canvas.width) * imgWidth

      ensureSpace(imgHeight + 24)
      line('Customer Segmentation Visualization', 13, 'bold', 20)
      doc.addImage(imgData, 'PNG', margin, y, imgWidth, imgHeight)
      y += imgHeight + 10
    } catch (err) {
      line('Customer Segmentation Visualization', 13, 'bold', 20)
      doc.setFont('helvetica', 'italic')
      doc.setFontSize(10)
      doc.text('Chart could not be rendered for this report.', margin, y)
      y += 18
    }
  }

  doc.save('market-basket-segmentation-report.pdf')
}
