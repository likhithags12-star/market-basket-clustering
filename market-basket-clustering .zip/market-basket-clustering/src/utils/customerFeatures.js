const MS_PER_DAY = 1000 * 60 * 60 * 24

/** All distinct categories present in the transaction data, sorted for stable ordering. */
export function uniqueCategories(transactions) {
  return [...new Set(transactions.map((t) => t.category))].sort()
}

/**
 * Aggregates raw transaction line items into one feature row per customer.
 * Recency is measured against the most recent transaction date found in the
 * whole dataset (used as a stand-in "today"), since the dataset has no
 * explicit reference date.
 */
export function buildCustomerFeatures(transactions) {
  const categories = uniqueCategories(transactions)
  const latestDate = new Date(Math.max(...transactions.map((t) => new Date(t.transaction_date).getTime())))

  const byCustomer = {}
  transactions.forEach((t) => {
    if (!byCustomer[t.customer_id]) {
      byCustomer[t.customer_id] = {
        customer_id: t.customer_id,
        transactionIds: new Set(),
        totalSpending: 0,
        totalQuantity: 0,
        products: new Set(),
        categories: new Set(),
        categorySpend: Object.fromEntries(categories.map((c) => [c, 0])),
        latestTransactionDate: t.transaction_date,
      }
    }
    const c = byCustomer[t.customer_id]
    c.transactionIds.add(t.transaction_id)
    c.totalSpending += t.total_amount
    c.totalQuantity += t.quantity
    c.products.add(t.product_id)
    c.categories.add(t.category)
    c.categorySpend[t.category] += t.total_amount
    if (new Date(t.transaction_date) > new Date(c.latestTransactionDate)) {
      c.latestTransactionDate = t.transaction_date
    }
  })

  return Object.values(byCustomer).map((c) => {
    const purchase_frequency = c.transactionIds.size
    const recency = Math.round((latestDate.getTime() - new Date(c.latestTransactionDate).getTime()) / MS_PER_DAY)

    const categoryPreferences = {}
    categories.forEach((cat) => {
      categoryPreferences[cat] = c.totalSpending > 0 ? c.categorySpend[cat] / c.totalSpending : 0
    })

    const topCategories = categories
      .map((cat) => ({ category: cat, spend: c.categorySpend[cat] }))
      .filter((e) => e.spend > 0)
      .sort((a, b) => b.spend - a.spend)
      .slice(0, 3)
      .map((e) => e.category)

    return {
      customer_id: c.customer_id,
      purchase_frequency,
      total_spending: Number(c.totalSpending.toFixed(2)),
      average_basket_value: Number((c.totalSpending / purchase_frequency).toFixed(2)),
      total_quantity: c.totalQuantity,
      unique_products: c.products.size,
      unique_categories: c.categories.size,
      recency,
      categoryPreferences,
      topCategories,
    }
  })
}

export { MS_PER_DAY }
