import { computeMeanStd } from '../ml/preprocessing'

const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length

/** Computes per-cluster averages from the labeled customer list. */
export function computeClusterStats(customers, k) {
  const stats = []
  for (let c = 0; c < k; c++) {
    const members = customers.filter((cust) => cust.segment === c)
    if (members.length === 0) {
      stats.push(null)
      continue
    }
    stats.push({
      segment: c,
      count: members.length,
      avgSpending: avg(members.map((m) => m.total_spending)),
      avgFrequency: avg(members.map((m) => m.purchase_frequency)),
      avgBasketValue: avg(members.map((m) => m.average_basket_value)),
      avgQuantity: avg(members.map((m) => m.total_quantity)),
      avgUniqueProducts: avg(members.map((m) => m.unique_products)),
      avgUniqueCategories: avg(members.map((m) => m.unique_categories)),
      avgRecency: avg(members.map((m) => m.recency)),
      topCategories: topCategoriesForGroup(members),
    })
  }
  return stats
}

function topCategoriesForGroup(members) {
  const counts = {}
  members.forEach((m) => {
    m.topCategories.forEach((cat, idx) => {
      const weight = 3 - idx // first choice weighted highest
      counts[cat] = (counts[cat] || 0) + weight
    })
  })
  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([cat]) => cat)
}

/**
 * Assigns a business-friendly name to each cluster based on how its averages
 * compare (z-score) to the overall dataset. Falls back to a generic label on
 * collisions so every segment still gets a distinct, descriptive name.
 */
export function nameSegments(customers, clusterStats) {
  const overall = computeMeanStd(customers)
  const zscore = (value, col) => (value - overall[col].mean) / overall[col].std

  const scored = clusterStats.map((stat) => {
    if (!stat) return null
    const spendingZ = zscore(stat.avgSpending, 'total_spending')
    const freqZ = zscore(stat.avgFrequency, 'purchase_frequency')
    const basketZ = zscore(stat.avgBasketValue, 'average_basket_value')
    const engagementZ = -zscore(stat.avgRecency, 'recency')
    return { ...stat, spendingZ, freqZ, basketZ, engagementZ }
  })

  const used = new Set()
  const pick = (name) => {
    if (!used.has(name)) {
      used.add(name)
      return name
    }
    return null
  }

  return scored.map((s) => {
    if (!s) return { name: 'Empty Segment', summary: 'No customers were assigned to this cluster.', topCategories: [] }

    let name = null
    if (s.spendingZ > 0.75 && s.freqZ > 0.5) name = pick('High Value Shoppers')
    if (!name && s.freqZ > 0.75) name = pick('Frequent Buyers')
    if (!name && s.basketZ > 0.75 && s.freqZ < 0.25) name = pick('Premium Buyers')
    if (!name && s.spendingZ < -0.5 && s.freqZ < 0) name = pick('Budget Shoppers')
    if (!name && s.engagementZ < -0.75) name = pick('Low Engagement Shoppers')
    if (!name) name = pick('Occasional Shoppers')
    if (!name) name = `Shopper Segment ${s.segment + 1}`

    const summary = buildSummary(name, s)
    return { name, summary, ...s }
  })
}

function buildSummary(name, s) {
  const spendPart = s.spendingZ > 0.5 ? 'high spending' : s.spendingZ < -0.5 ? 'low spending' : 'moderate spending'
  const freqPart = s.freqZ > 0.5 ? 'frequent transactions' : s.freqZ < -0.5 ? 'infrequent transactions' : 'occasional transactions'
  return `${name} show ${spendPart} and ${freqPart}, averaging ${Math.round(s.avgRecency)} days since their last purchase.`
}

/** One-line purchasing summary for a single customer, used in the detail panel. */
export function customerPurchasingSummary(customer, overallStats) {
  const spendingHigh = customer.total_spending > overallStats.total_spending.mean
  const freqHigh = customer.purchase_frequency > overallStats.purchase_frequency.mean

  const spendPart = spendingHigh ? 'high spending' : 'below-average spending'
  const freqPart = freqHigh ? 'frequent purchases' : 'infrequent purchases'

  return `This customer makes ${freqPart} and has ${spendPart}.`
}
