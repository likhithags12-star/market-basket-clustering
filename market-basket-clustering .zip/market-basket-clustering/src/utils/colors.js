export const CLUSTER_COLORS = ['#7A4F8C', '#D98A3D', '#3E8265', '#B24A6B', '#4C6FD5', '#8E6B2E']

export function colorForCluster(index) {
  return CLUSTER_COLORS[index % CLUSTER_COLORS.length]
}
