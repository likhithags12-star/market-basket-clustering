import Papa from 'papaparse'

const REQUIRED_NUMERIC = ['quantity', 'unit_price', 'total_amount']

/** Loads and parses the raw transaction dataset shipped with the app. */
export async function loadDataset() {
  let response
  try {
    response = await fetch('/data/transactions.csv')
  } catch (err) {
    throw new Error('Could not reach the dataset file. Check your connection and reload.')
  }

  if (!response.ok) {
    throw new Error(`Dataset file not found (status ${response.status}). Expected public/data/transactions.csv.`)
  }

  const csvText = await response.text()

  const parsed = Papa.parse(csvText, {
    header: true,
    dynamicTyping: true,
    skipEmptyLines: true,
  })

  if (parsed.errors && parsed.errors.length > 0) {
    throw new Error('The dataset CSV is malformed and could not be parsed.')
  }

  const rows = parsed.data.filter((row) => {
    const validDate = typeof row.transaction_date === 'string' && !Number.isNaN(new Date(row.transaction_date).getTime())
    return typeof row.transaction_id !== 'undefined' && row.transaction_id !== null
      && typeof row.customer_id !== 'undefined' && row.customer_id !== null
      && typeof row.product_name === 'string' && row.product_name.trim().length > 0
      && typeof row.category === 'string' && row.category.trim().length > 0
      && validDate
      && REQUIRED_NUMERIC.every((field) => typeof row[field] === 'number' && !Number.isNaN(row[field]))
  })

  if (rows.length < 100) {
    throw new Error('Dataset has too few valid transaction rows to build reliable customer features.')
  }

  return rows
}

const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length

export function computeTransactionSummary(transactions, customers) {
  const uniqueProducts = new Set(transactions.map((t) => t.product_id)).size
  const uniqueTransactions = new Set(transactions.map((t) => t.transaction_id)).size
  const totalRevenue = transactions.reduce((a, t) => a + t.total_amount, 0)

  return {
    totalTransactions: uniqueTransactions,
    totalCustomers: customers.length,
    totalProducts: uniqueProducts,
    averageBasketValue: avg(customers.map((c) => c.average_basket_value)),
    averagePurchaseFrequency: avg(customers.map((c) => c.purchase_frequency)),
    totalRevenue,
  }
}

export function productPopularity(transactions) {
  const byProduct = {}
  transactions.forEach((t) => {
    if (!byProduct[t.product_name]) {
      byProduct[t.product_name] = { product_name: t.product_name, unitsSold: 0, revenue: 0, customers: new Set() }
    }
    byProduct[t.product_name].unitsSold += t.quantity
    byProduct[t.product_name].revenue += t.total_amount
    byProduct[t.product_name].customers.add(t.customer_id)
  })
  return Object.values(byProduct)
    .map((p) => ({ ...p, customerCount: p.customers.size, customers: undefined }))
    .sort((a, b) => b.revenue - a.revenue)
}

export function categoryPopularity(transactions) {
  const byCategory = {}
  transactions.forEach((t) => {
    if (!byCategory[t.category]) {
      byCategory[t.category] = { category: t.category, unitsSold: 0, revenue: 0, customers: new Set(), transactionValues: [] }
    }
    byCategory[t.category].unitsSold += t.quantity
    byCategory[t.category].revenue += t.total_amount
    byCategory[t.category].customers.add(t.customer_id)
    byCategory[t.category].transactionValues.push(t.total_amount)
  })
  return Object.values(byCategory)
    .map((c) => ({
      category: c.category,
      unitsSold: c.unitsSold,
      revenue: c.revenue,
      customerCount: c.customers.size,
      averagePurchaseValue: avg(c.transactionValues),
    }))
    .sort((a, b) => b.revenue - a.revenue)
}

export function histogram(values, buckets = 6) {
  const min = Math.min(...values)
  const max = Math.max(...values)
  const width = (max - min) / buckets || 1
  const bins = Array.from({ length: buckets }, (_, i) => ({
    range: `${Math.round(min + i * width)}-${Math.round(min + (i + 1) * width)}`,
    count: 0,
  }))
  values.forEach((v) => {
    let idx = Math.floor((v - min) / width)
    if (idx >= buckets) idx = buckets - 1
    if (idx < 0) idx = 0
    bins[idx].count += 1
  })
  return bins
}
