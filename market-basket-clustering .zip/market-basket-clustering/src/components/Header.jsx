import React from 'react'

const TITLES = {
  dashboard: ['Dashboard', 'Transaction overview from the loaded dataset'],
  segments: ['Customer Segments', 'K-Means clusters and their business-friendly names'],
  analysis: ['Purchase Analysis', 'Category and product performance across all transactions'],
  performance: ['Cluster Performance', 'How well the current clustering separates shoppers'],
}

export default function Header({ activePage, onMenuClick, status }) {
  const [title, subtitle] = TITLES[activePage] || ['', '']
  return (
    <header className="sticky top-0 z-10 bg-paper/95 backdrop-blur border-b border-black/5 px-4 md:px-8 py-4 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <button className="md:hidden p-2 -ml-2 rounded hover:bg-black/5" onClick={onMenuClick} aria-label="Open navigation">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 6h18M3 12h18M3 18h18" />
          </svg>
        </button>
        <div>
          <h1 className="font-display text-xl md:text-2xl text-ink">{title}</h1>
          <p className="text-sm text-ink/50">{subtitle}</p>
        </div>
      </div>
      <div className="hidden sm:flex items-center gap-2 text-xs px-3 py-1.5 rounded-full bg-white border border-black/5">
        <span
          className={`w-2 h-2 rounded-full ${
            status === 'ready' ? 'bg-pine' : status === 'error' ? 'bg-red-500' : 'bg-saffron animate-pulse'
          }`}
        />
        <span className="text-ink/60">
          {status === 'ready' ? 'Segmentation ready' : status === 'error' ? 'Segmentation error' : 'Segmenting…'}
        </span>
      </div>
    </header>
  )
}
