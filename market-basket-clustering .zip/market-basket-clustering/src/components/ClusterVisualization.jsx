import React from 'react'
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import ChartCard from './ChartCard'
import { colorForCluster } from '../utils/colors'
import { formatINR } from '../utils/currency'

function CustomTooltip({ active, payload }) {
  if (!active || !payload || !payload.length) return null
  const c = payload[0].payload
  return (
    <div className="bg-white border border-black/10 rounded-md px-3 py-2 text-xs shadow-sm">
      <p className="font-medium text-ink mb-1">Customer {c.customer_id}</p>
      <p className="text-ink/60">Spending: {formatINR(c.total_spending)}</p>
      <p className="text-ink/60">Frequency: {c.purchase_frequency}</p>
      <p className="text-ink/60">Avg Basket: {formatINR(c.average_basket_value)}</p>
      <p className="text-ink/60">Unique Products: {c.unique_products}</p>
      <p className="text-ink/60">Segment: {c.segment + 1}</p>
    </div>
  )
}

export default function ClusterVisualization({ customers, description, innerRef }) {
  return (
    <ChartCard innerRef={innerRef} title="Cluster Visualization" description={description || 'Total spending vs purchase frequency, colored by segment'}>
      <ResponsiveContainer width="100%" height="100%">
        <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
          <CartesianGrid stroke="#eae7ee" />
          <XAxis type="number" dataKey="total_spending" name="Total Spending" tick={{ fontSize: 11 }} />
          <YAxis type="number" dataKey="purchase_frequency" name="Purchase Frequency" tick={{ fontSize: 11 }} />
          <Tooltip content={<CustomTooltip />} />
          <Scatter data={customers}>
            {customers.map((c, i) => (
              <Cell key={i} fill={colorForCluster(c.segment)} />
            ))}
          </Scatter>
        </ScatterChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}
