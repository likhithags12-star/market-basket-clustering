import React from 'react'
import { formatINR } from '../utils/currency'
import { colorForCluster } from '../utils/colors'
import { customerPurchasingSummary } from '../utils/segmentInsights'

export default function CustomerDetails({ customer, segmentNames, overallStats }) {
  if (!customer) {
    return (
      <div className="bg-white rounded-lg border border-black/5 border-dashed p-6 text-center text-ink/40 text-sm">
        Select a customer from the table to see their details.
      </div>
    )
  }

  const rows = [
    ['Customer ID', customer.customer_id],
    ['Purchase Frequency', customer.purchase_frequency],
    ['Total Spending', formatINR(customer.total_spending)],
    ['Average Basket Value', formatINR(customer.average_basket_value)],
    ['Total Quantity', customer.total_quantity],
    ['Unique Products', customer.unique_products],
    ['Unique Categories', customer.unique_categories],
    ['Recency', `${customer.recency} days`],
  ]

  const segment = segmentNames[customer.segment]

  return (
    <div className="bg-white rounded-lg border border-black/5 p-6">
      <div className="flex items-center gap-2 mb-4">
        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: colorForCluster(customer.segment) }} />
        <p className="text-xs uppercase tracking-wide text-ink/40">Assigned Segment</p>
      </div>
      <h3 className="font-display text-xl text-ink mb-4">{segment?.name}</h3>

      <div className="space-y-2 mb-5">
        {rows.map(([label, value]) => (
          <div key={label} className="flex justify-between text-sm py-1.5 border-b border-black/5 last:border-0">
            <span className="text-ink/50">{label}</span>
            <span className="text-ink font-medium">{value}</span>
          </div>
        ))}
      </div>

      {customer.topCategories?.length > 0 && (
        <div className="mb-4">
          <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Top Categories</p>
          <div className="flex flex-wrap gap-1.5">
            {customer.topCategories.map((cat) => (
              <span key={cat} className="text-xs px-2 py-1 rounded-full bg-black/5 text-ink/60">{cat}</span>
            ))}
          </div>
        </div>
      )}

      <div className="bg-paper rounded-md p-4">
        <p className="text-xs uppercase tracking-wide text-ink/40 mb-1">Purchasing Summary</p>
        <p className="text-sm text-ink/70">{customerPurchasingSummary(customer, overallStats)}</p>
      </div>
    </div>
  )
}
