import React from 'react'

export default function ChartCard({ title, description, children, className = '', innerRef }) {
  return (
    <div ref={innerRef} className={`bg-white rounded-lg border border-black/5 p-5 ${className}`}>
      <div className="mb-3">
        <h3 className="text-sm font-medium text-ink">{title}</h3>
        {description && <p className="text-xs text-ink/40 mt-0.5">{description}</p>}
      </div>
      <div className="w-full" style={{ height: 280 }}>
        {children}
      </div>
    </div>
  )
}
