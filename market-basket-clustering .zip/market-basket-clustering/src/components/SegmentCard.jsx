import React from 'react'
import { formatINR } from '../utils/currency'
import { colorForCluster } from '../utils/colors'

export default function SegmentCard({ segment, onSelect, selected }) {
  return (
    <button
      onClick={onSelect}
      className={`w-full text-left bg-white rounded-lg border p-5 transition-colors ${
        selected ? 'border-ink' : 'border-black/5 hover:border-black/15'
      }`}
    >
      <div className="flex items-center gap-2 mb-1">
        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: colorForCluster(segment.segment) }} />
        <p className="text-xs uppercase tracking-wide text-ink/40">Segment {segment.segment + 1}</p>
      </div>
      <h3 className="font-display text-lg text-ink mb-1">{segment.name}</h3>
      <p className="text-sm text-ink/50 mb-4">{segment.count} customers</p>

      <div className="grid grid-cols-2 gap-3 text-sm mb-4">
        <div>
          <p className="text-xs text-ink/40">Avg Spending</p>
          <p className="font-medium text-ink">{formatINR(segment.avgSpending)}</p>
        </div>
        <div>
          <p className="text-xs text-ink/40">Purchase Frequency</p>
          <p className="font-medium text-ink">{segment.avgFrequency.toFixed(1)}</p>
        </div>
        <div>
          <p className="text-xs text-ink/40">Avg Basket</p>
          <p className="font-medium text-ink">{formatINR(segment.avgBasketValue)}</p>
        </div>
        <div>
          <p className="text-xs text-ink/40">Avg Recency</p>
          <p className="font-medium text-ink">{Math.round(segment.avgRecency)} days</p>
        </div>
      </div>

      {segment.topCategories?.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-3">
          {segment.topCategories.map((cat) => (
            <span key={cat} className="text-xs px-2 py-0.5 rounded-full bg-black/5 text-ink/60">{cat}</span>
          ))}
        </div>
      )}

      <p className="text-xs text-ink/50 leading-relaxed">{segment.summary}</p>
    </button>
  )
}
