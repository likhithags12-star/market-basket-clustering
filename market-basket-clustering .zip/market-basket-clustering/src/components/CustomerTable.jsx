import React, { useMemo, useState } from 'react'
import { formatINR } from '../utils/currency'
import { colorForCluster } from '../utils/colors'

const PAGE_SIZE = 10

const COLUMNS = [
  { key: 'customer_id', label: 'Customer ID' },
  { key: 'purchase_frequency', label: 'Frequency' },
  { key: 'total_spending', label: 'Spending' },
  { key: 'average_basket_value', label: 'Avg Basket' },
  { key: 'total_quantity', label: 'Quantity' },
  { key: 'unique_products', label: 'Products' },
  { key: 'unique_categories', label: 'Categories' },
  { key: 'recency', label: 'Recency' },
  { key: 'segment', label: 'Segment' },
]

export default function CustomerTable({ customers, segmentNames, onSelect, selectedId }) {
  const [search, setSearch] = useState('')
  const [segmentFilter, setSegmentFilter] = useState('all')
  const [sortKey, setSortKey] = useState('total_spending')
  const [sortDir, setSortDir] = useState('desc')
  const [page, setPage] = useState(1)

  const filtered = useMemo(() => {
    let result = customers
    if (search.trim()) {
      const q = search.trim().toLowerCase()
      result = result.filter((c) => String(c.customer_id).toLowerCase().includes(q))
    }
    if (segmentFilter !== 'all') {
      result = result.filter((c) => c.segment === Number(segmentFilter))
    }
    const sorted = [...result].sort((a, b) => {
      const diff = a[sortKey] - b[sortKey]
      return sortDir === 'asc' ? diff : -diff
    })
    return sorted
  }, [customers, search, segmentFilter, sortKey, sortDir])

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const currentPage = Math.min(page, totalPages)
  const pageRows = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE)

  const toggleSort = (key) => {
    if (sortKey === key) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))
    } else {
      setSortKey(key)
      setSortDir('desc')
    }
    setPage(1)
  }

  return (
    <div className="bg-white rounded-lg border border-black/5 p-5">
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <input
          type="text"
          placeholder="Search by Customer ID"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1) }}
          className="flex-1 border border-black/10 rounded-md px-3 py-2 text-sm"
        />
        <select
          value={segmentFilter}
          onChange={(e) => { setSegmentFilter(e.target.value); setPage(1) }}
          className="border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
        >
          <option value="all">All Segments</option>
          {segmentNames.map((s, i) => (
            <option key={i} value={i}>{s.name}</option>
          ))}
        </select>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm min-w-[760px]">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wide text-ink/40 border-b border-black/5">
              {COLUMNS.map((col) => (
                <th
                  key={col.key}
                  onClick={() => toggleSort(col.key)}
                  className="py-2 pr-4 cursor-pointer select-none whitespace-nowrap"
                >
                  {col.label}{sortKey === col.key ? (sortDir === 'asc' ? ' ▲' : ' ▼') : ''}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageRows.map((c) => (
              <tr
                key={c.customer_id}
                onClick={() => onSelect(c)}
                className={`border-b border-black/5 last:border-0 cursor-pointer hover:bg-black/[0.02] ${
                  selectedId === c.customer_id ? 'bg-black/[0.03]' : ''
                }`}
              >
                <td className="py-2 pr-4 whitespace-nowrap">{c.customer_id}</td>
                <td className="py-2 pr-4">{c.purchase_frequency}</td>
                <td className="py-2 pr-4 whitespace-nowrap">{formatINR(c.total_spending)}</td>
                <td className="py-2 pr-4 whitespace-nowrap">{formatINR(c.average_basket_value)}</td>
                <td className="py-2 pr-4">{c.total_quantity}</td>
                <td className="py-2 pr-4">{c.unique_products}</td>
                <td className="py-2 pr-4">{c.unique_categories}</td>
                <td className="py-2 pr-4">{c.recency}d</td>
                <td className="py-2 pr-4 whitespace-nowrap">
                  <span className="inline-flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: colorForCluster(c.segment) }} />
                    {segmentNames[c.segment]?.name}
                  </span>
                </td>
              </tr>
            ))}
            {pageRows.length === 0 && (
              <tr>
                <td colSpan={COLUMNS.length} className="py-6 text-center text-ink/40">No customers match your filters.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between mt-4 text-sm text-ink/50">
        <span>{filtered.length} customers</span>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={currentPage <= 1}
            className="px-3 py-1 rounded border border-black/10 disabled:opacity-40"
          >
            Prev
          </button>
          <span>{currentPage} / {totalPages}</span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage >= totalPages}
            className="px-3 py-1 rounded border border-black/10 disabled:opacity-40"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  )
}
