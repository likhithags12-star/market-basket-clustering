# Market Basket Analysis with Clustering

Frontend-only ML app. React + Vite + Tailwind + K-Means clustering + Recharts + PapaParse + jsPDF + html2canvas.
No backend, no external APIs. Transaction loading, feature engineering, clustering, and PDF report all run
in the browser.

Clustering uses the same lightweight from-scratch K-Means implementation as its sibling segmentation
projects (k-means++ init + Lloyd's algorithm, src/ml/kmeans.js) instead of the full TensorFlow.js bundle.

## Run it

npm install
npm run dev

Open the printed local URL. First load: raw transactions load, get aggregated into per-customer features,
features are normalized, then K-Means runs (K=4 by default) before the dashboard is ready.

## Structure

- public/data/transactions.csv — ~7,900 line-item transactions across 300 customers, 5 categories, and
  5 shopping archetypes (high value, frequent, premium, budget, occasional)
- src/utils/customerFeatures.js — aggregates raw transaction rows into one feature row per customer
  (purchase frequency, total spending, average basket value, total quantity, unique products/categories,
  recency, category-spend preferences)
- src/ml/ — preprocessing (normalization), kmeans.js (the algorithm), clustering.js (orchestration)
- src/services/dataset.js — CSV loading + transaction-level summary/product/category helpers
- src/utils/segmentInsights.js — per-cluster stats + rule-based business-friendly naming
- src/pages/ — Dashboard, Customer Segments, Purchase Analysis, Cluster Performance
- src/components/ — Sidebar, Header, StatCard, ChartCard, SegmentCard, CustomerTable, CustomerDetails,
  ClusterVisualization, ReportButton
- src/utils/reportGenerator.js — builds the downloadable PDF (jsPDF + html2canvas)

Swap in your own data by replacing public/data/transactions.csv, keeping the same column names
(transaction_id, customer_id, transaction_date, product_id, product_name, category, quantity, unit_price,
total_amount). Recency is computed against the latest transaction date found in the dataset, so it
adapts automatically to whatever date range you load.

## Changing K

On the Customer Segments page, pick 2–6 clusters. Changing K re-runs K-Means, recalculates centroids,
reassigns every customer, and updates all charts, segment cards, and metrics.

## Report download

On the Customer Segments page, "Download Report" generates market-basket-segmentation-report.pdf with
the transaction/customer summary, current K, per-segment stats and insights (including top categories),
clustering metrics (inertia, silhouette score), purchase insights, and the segmentation chart — all from
the current session. Blocks with "Please wait for segmentation to complete first" if clustering hasn't
finished yet.
